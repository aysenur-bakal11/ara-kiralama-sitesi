<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kiralama Güncelle</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #121212;
            color: #ffffff;
        }

        .navbar-dark .navbar-brand,
        .navbar-dark .nav-link {
            color: rgba(255, 255, 255, 0.85);
        }

        .navbar-dark .nav-link.active {
            font-weight: bold;
        }

        label,
        h2 {
            color: #ffffff;
        }

        .form-control,
        .form-select {
            background-color: #1f1f1f;
            color: #ffffff;
            border: 1px solid #333;
        }

        .form-control:focus,
        .form-select:focus {
            border-color: #555;
            box-shadow: none;
        }

        .btn-warning {
            background-color: #ffc107;
            border-color: #ffc107;
            color: #000;
        }

        .btn-warning:hover {
            background-color: #e0a800;
            border-color: #d39e00;
        }
    </style>
</head>

<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <a class="navbar-brand" href="index.html">Şirket Adı</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
                aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" href="index.html">Anasayfa</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="kiralamalistesi.php">Kiralama Listesi</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="kiralamaekle.php">Kiralama Ekle</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Kiralama Güncelleme -->
    <div class="container mt-4">
        <h2 class="mb-4">Kiralama Güncelle</h2>
        <form action="" method="POST">
            <div class="mb-3">
                <label for="tcno" class="form-label">Müşteri Seç</label>
                <select class="form-select" id="tcno" name="tcno" required>
                    <?php foreach ($musteriler as $musteri): ?>
                        <option value="<?= $musteri['tcno'] ?>" <?= ($musteri['tcno'] == $rental['tcno']) ? 'selected' : '' ?>>
                            <?= $musteri['adi'] . ' ' . $musteri['soyadi'] ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="mb-3">
                <label for="plaka" class="form-label">Araç Seç</label>
                <select class="form-select" id="plaka" name="plaka" required onchange="updateUcret()">
                    <?php foreach ($arabalar as $araba): ?>
                        <option value="<?= $araba['plaka'] ?>" data-ucret="<?= $araba['fiyat'] ?>"
                            <?= ($araba['plaka'] == $rental['plaka']) ? 'selected' : '' ?>>
                            <?= $araba['model'] ?> - <?= $araba['plaka'] ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="mb-3">
                <label for="baslangic-tarihi" class="form-label">Başlangıç Tarihi</label>
                <input type="date" class="form-control" id="baslangic-tarihi" name="baslangic_tarihi"
                    value="<?= date('Y-m-d', strtotime($rental['baslangic'])) ?>" required>
            </div>
            <div class="mb-3">
                <label for="bitis-tarihi" class="form-label">Bitiş Tarihi</label>
                <input type="date" class="form-control" id="bitis-tarihi" name="bitis_tarihi"
                    value="<?= date('Y-m-d', strtotime($rental['bitis'])) ?>" required>
            </div>
            <div class="mb-3">
                <label for="ucret" class="form-label">Ücret</label>
                <input type="number" class="form-control" id="ucret" name="ucret" value="<?= $rental['ucret'] ?>"
                    readonly>
            </div>
            <button type="submit" class="btn btn-warning">Güncelle</button>
        </form>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        function updateUcret() {
            const selectBox = document.getElementById('plaka');
            const selectedOption = selectBox.options[selectBox.selectedIndex];
            const ucret = selectedOption.getAttribute('data-ucret');
            document.getElementById('ucret').value = ucret;
        }
    </script>
</body>

</html>
