<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kiralama Ekle</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #121212;
            color: #ffffff;
        }

        .navbar-dark .navbar-brand,
        .navbar-dark .nav-link {
            color: rgba(255, 255, 255, 0.85);
        }

        .navbar-dark .nav-link.active {
            font-weight: bold;
        }

        label,
        h2,
        h4 {
            color: #ffffff;
        }

        .form-control,
        .form-select {
            background-color: #1f1f1f;
            color: #ffffff;
            border: 1px solid #333;
        }

        .form-control:focus,
        .form-select:focus {
            border-color: #555;
            box-shadow: none;
        }

        .btn-success {
            background-color: #198754;
            border-color: #198754;
        }

        .btn-success:hover {
            background-color: #157347;
            border-color: #146c43;
        }

        .btn-secondary {
            background-color: #6c757d;
            border-color: #6c757d;
        }

        .btn-secondary:hover {
            background-color: #5a6268;
            border-color: #545b62;
        }
    </style>
</head>

<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <a class="navbar-brand" href="index.php">Şirket Adı</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
                aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" href="index.php">Anasayfa</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="kiralamalistesi.php">Kiralama Listesi</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="kiralamaekle.php">Kiralama Ekle</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Kiralama Ekleme -->
    <div class="container mt-4">
        <h2 class="mb-4">Kiralama Ekle</h2>

        <!-- Kiralama Bilgileri -->
        <div class="container border border-light p-4 mb-4">
            <h4>Kiralama Bilgileri</h4>
            <form action="" method="POST">
                <div class="mb-3">
                    <label for="musteri" class="form-label">Müşteri Seçin</label>
                    <select class="form-select" id="musteri" name="tcno" required>
                        <option value="" disabled selected>Müşteri Seçin</option>
                        <?php foreach ($customers as $customer): ?>
                            <option value="<?= $customer['tcno'] ?>"><?= $customer['adi'] ?> <?= $customer['soyadi'] ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="mb-3">
                    <label for="arac" class="form-label">Araç Seçin</label>
                    <select class="form-select" id="arac" name="plaka" required onchange="setUcretDepozito()">
                        <option value="" disabled selected>Araç Seçin</option>
                        <?php foreach ($cars as $car): ?>
                            <option value="<?= $car['plaka'] ?>" data-fiyat="<?= $car['fiyat'] ?>"
                                data-depozito="<?= $car['depozito'] ?>">
                                <?= $car['model'] ?> (<?= $car['plaka'] ?>)
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="mb-3">
                    <label for="baslangic-tarihi" class="form-label">Başlangıç Tarihi</label>
                    <input type="date" class="form-control" id="baslangic-tarihi" name="baslangic_tarihi" required>
                </div>
                <div class="mb-3">
                    <label for="bitis-tarihi" class="form-label">Bitiş Tarihi</label>
                    <input type="date" class="form-control" id="bitis-tarihi" name="bitis_tarihi" required>
                </div>
                <div class="mb-3">
                    <label for="ucret" class="form-label">Ücret</label>
                    <input type="number" class="form-control" id="ucret" name="ucret" readonly required>
                </div>
                <div class="mb-3">
                    <label for="depozito" class="form-label">Depozito</label>
                    <input type="number" class="form-control" id="depozito" readonly>
                </div>
                <button type="submit" class="btn btn-success">Kirala</button>
            </form>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        function setUcretDepozito() {
            const aracSelect = document.getElementById('arac');
            const selectedOption = aracSelect.options[aracSelect.selectedIndex];
            const fiyat = selectedOption.getAttribute('data-fiyat');
            const depozito = selectedOption.getAttribute('data-depozito');
            document.getElementById('ucret').value = fiyat;
            document.getElementById('depozito').value = depozito;
        }
    </script>
</body>

</html>
