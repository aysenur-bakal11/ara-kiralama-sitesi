<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Müşteri Sil</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #121212;
            color: #ffffff;
        }

        .navbar-dark .navbar-brand,
        .navbar-dark .nav-link {
            color: rgba(255, 255, 255, 0.85);
        }

        .navbar-dark .nav-link.active {
            font-weight: bold;
        }

        .navbar-light {
            background-color: #212121;
        }

        .container {
            background-color: #1f1f1f;
            border-radius: 8px;
            padding: 30px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
        }

        .btn-secondary,
        .btn-danger {
            font-size: 1rem;
        }

        .btn-secondary {
            background-color: #6c757d;
            border-color: #6c757d;
        }

        .btn-secondary:hover {
            background-color: #5a6268;
            border-color: #545b62;
        }

        .btn-danger {
            background-color: #e74c3c;
            border-color: #e74c3c;
        }

        .btn-danger:hover {
            background-color: #c0392b;
            border-color: #c0392b;
        }

        .btn-sm {
            padding: 5px 10px;
            font-size: 0.875rem;
        }

        .navbar-toggler-icon {
            background-color: #ffffff;
        }

        .border {
            border-color: #555;
        }

        .text-danger {
            color: #e74c3c !important;
        }

        h2 {
            color: #e74c3c;
        }
    </style>
</head>

<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <a class="navbar-brand" href="index.php">Şirket Adı</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
                aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" href="index.php">Anasayfa</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="musteriler.php">Müşteri Listesi</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="musteriekle.php">Müşteri Ekle</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Müşteri Silme -->
    <div class="container mt-4">
        <h2 class="mb-4 text-danger">Müşteri Sil</h2>
        <p class="mb-4">Aşağıdaki müşteri kaydını silmek istediğinize emin misiniz?</p>

        <!-- Müşteri Bilgileri -->
        <div class="border p-3 mb-4">
            <p><strong>Ad:</strong> <?= $customer['adi'] ?></p>
            <p><strong>Soyad:</strong> <?= $customer['soyadi'] ?></p>
            <p><strong>Telefon:</strong> <?= $customer['tlf'] ?></p>
            <p><strong>Email:</strong> <?= $customer['email'] ?></p>
        </div>

        <!-- Silme İşlemi -->
        <form action="" method="POST">
            <div class="d-flex justify-content-between">
                <a href="musteriler.php" class="btn btn-secondary">İptal</a>
                <button type="submit" class="btn btn-danger">Müşteri Sil</button>
            </div>
        </form>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>
