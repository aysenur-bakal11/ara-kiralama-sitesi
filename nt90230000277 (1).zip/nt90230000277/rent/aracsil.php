<?php

include_once 'app/config.php';
include_once 'app/arabalarclass.php';

if (isset($_GET['plaka'])) {
    $plaka = $_GET['plaka'];

    $araba = new Arabalar();
    $car = $araba->aracdetayi($plaka);

    if (!$car) {
        die("Araç bulunamadı.");
    }

    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        if ($araba->aracsil($plaka)) {
            header("Location: araclar.php");
            exit;
        } else {
            die("Araç silinirken bir hata oluştu.");
        }
    }
} else {
    die("Geçersiz istek.");
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Araç Sil</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #121212;
            color: #ffffff;
        }

        .navbar-dark .navbar-brand,
        .navbar-dark .nav-link {
            color: rgba(255, 255, 255, 0.85);
        }

        .navbar-dark .nav-link.active {
            font-weight: bold;
        }

        .border {
            background-color: #1f1f1f;
            border-color: #444;
        }

        .btn-danger {
            background-color: #dc3545;
            border-color: #dc3545;
        }

        .btn-danger:hover {
            background-color: #c82333;
        }

        .btn-secondary {
            background-color: #6c757d;
            border-color: #6c757d;
        }

        .btn-secondary:hover {
            background-color: #5a6268;
        }
    </style>
</head>

<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <a class="navbar-brand" href="index.php">Şirket Adı</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
                aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" href="index.php">Anasayfa</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="araclar.php">Araç Listesi</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="aracekle.php">Araç Ekle</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Araç Silme -->
    <div class="container mt-4">
        <h2 class="mb-4 text-danger">Araç Sil</h2>
        <p class="mb-4">Aşağıdaki araç kaydını silmek istediğinize emin misiniz?</p>

        <!-- Araç Bilgileri -->
        <div class="border p-3 mb-4">
            <p><strong>Plaka:</strong> <?= $car['plaka'] ?></p>
            <p><strong>Model:</strong> <?= $car['model'] ?></p>
            <p><strong>Renk:</strong> <?= $car['renk'] ?></p>
            <p><strong>Fiyat:</strong> <?= $car['fiyat'] ?> TL</p>
        </div>

        <!-- Silme İşlemi -->
        <form action="" method="POST">
            <div class="d-flex justify-content-between">
                <a href="araclar.php" class="btn btn-secondary">İptal</a>
                <button type="submit" class="btn btn-danger">Araç Sil</button>
            </div>
        </form>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>
