<?php

include_once 'app/config.php';
include_once 'app/arabalarclass.php';

try {
    $araba = new Arabalar();
    $cars = $araba->araclarilistele();
} catch (Exception $e) {
    die("Veritabanı hatası: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Araçlar</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #121212; /* Karanlık tema arka plan */
            color: #ffffff; /* Açık renk yazı */
        }

        .navbar-dark .navbar-brand,
        .navbar-dark .nav-link {
            color: rgba(255, 255, 255, 0.85);
        }

        .navbar-dark .nav-link.active {
            font-weight: bold;
        }

        .table-dark {
            background-color: #1e1e1e;
        }

        .table-striped > tbody > tr:nth-of-type(odd) {
            background-color: #2c2c2c;
        }

        .table-striped > tbody > tr:nth-of-type(even) {
            background-color: #1e1e1e;
        }

        .btn-warning {
            background-color: #ffc107;
            border-color: #ffc107;
        }

        .btn-warning:hover {
            background-color: #ffca2c;
        }

        .btn-danger {
            background-color: #dc3545;
            border-color: #dc3545;
        }

        .btn-danger:hover {
            background-color: #c82333;
        }

        .form-control {
            background-color: #1f1f1f;
            color: #ffffff;
            border: 1px solid #444;
        }

        .form-control:focus {
            background-color: #333;
            border-color: #555;
        }
    </style>
</head>

<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <a class="navbar-brand" href="index.php">Şirket Adı</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
                aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" href="index.php">Anasayfa</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="araclar.php">Araç Listesi</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="aracekle.php">Araç Ekle</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Araç Listesi -->
    <div class="container mt-4">
        <div class="row justify-content-between">
            <h2 class="mb-4 col-lg-4">Araç Listesi</h2>
            <div class="input-group w-50 mb-4">
                <input type="text" class="form-control" placeholder="Arama yap..." name="search">
                <button class="btn btn-primary" type="submit">
                    <i class="fas fa-search"></i>
                </button>
            </div>
        </div>
        <table class="table table-dark table-striped">
            <thead>
                <tr>
                    <th scope="col">Plaka</th>
                    <th scope="col">KM</th>
                    <th scope="col">Model</th>
                    <th scope="col">Renk</th>
                    <th scope="col">Fiyat</th>
                    <th scope="col">Otomatik</th>
                    <th scope="col">Depozito</th>
                    <th scope="col">Yakıt Türü</th>
                    <th scope="col">Motor Gücü</th>
                    <th scope="col">Yaş</th>
                    <th scope="col">Şase No</th>
                    <th scope="col">Güncelle</th>
                    <th scope="col">Sil</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($cars): ?>
                    <?php foreach ($cars as $car): ?>
                        <tr>
                            <td><?= $car['plaka'] ?></td>
                            <td><?= $car['km'] ?></td>
                            <td><?= $car['model'] ?></td>
                            <td><?= $car['renk'] ?></td>
                            <td><?= $car['fiyat'] ?> TL</td>
                            <td><?= $car['otomatik'] == 1 ? 'Evet' : 'Hayır' ?></td>
                            <td><?= $car['depozito'] ?> TL</td>
                            <td><?= $car['yakitturu'] ?></td>
                            <td><?= $car['motorgucu'] ?> HP</td>
                            <td><?= $car['yas'] ?></td>
                            <td><?= $car['saseno'] ?></td>
                            <td>
                                <a href="aracguncelle.php?plaka=<?= $car['plaka'] ?>" class="btn btn-warning btn-sm">
                                    <i class="fas fa-edit"></i> Güncelle
                                </a>
                            </td>
                            <td>
                                <a href="aracsil.php?plaka=<?= $car['plaka'] ?>" class="btn btn-danger btn-sm">
                                    <i class="fas fa-trash"></i> Sil
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="13" class="text-center">Kayıtlı araç bulunamadı.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <!-- Font Awesome -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/js/all.min.js"></script>
</body>

</html>
