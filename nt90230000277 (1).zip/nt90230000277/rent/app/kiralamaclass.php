<?php

include_once 'config.php';
include_once 'db_cnn.php';

class Kiralama extends DBConnect
{
    public function __construct()
    {
        parent::__construct();
    }

    // Kiralama ekleme
    public function kiralamaekle($tcno, $plaka, $baslangic_tarihi, $bitis_tarihi, $ucret)
    {
        $sql = "INSERT INTO kiralama (tcno, plaka, baslangic, bitis, ucret) 
                VALUES (?, ?, ?, ?, ?)";
        try {
            $stmt = $this->db->prepare($sql);
            $stmt->execute([$tcno, $plaka, $baslangic_tarihi, $bitis_tarihi, $ucret]);
            return true;
        } catch (PDOException $e) {
            echo 'Kiralama ekleme hatası: ' . $e->getMessage();
            return false;
        }
    }

    // Kiralama güncelleme
    public function kiralamaguncelle($tcno, $plaka, $baslangic_tarihi, $bitis_tarihi, $ucret)
    {
        $sql = "UPDATE kiralama SET baslangic = ?, bitis = ?, ucret = ? WHERE tcno = ? AND plaka = ?";
        try {
            $stmt = $this->db->prepare($sql);
            $stmt->execute([$baslangic_tarihi, $bitis_tarihi, $ucret, $tcno, $plaka]);
            return true;
        } catch (PDOException $e) {
            echo 'Kiralama güncelleme hatası: ' . $e->getMessage();
            return false;
        }
    }

    // Kiralama silme
    public function kiralamasil($tcno, $plaka)
    {
        $sql = "DELETE FROM kiralama WHERE tcno = :tcno AND plaka = :plaka";
        $stmt = $this->db->prepare($sql);
        $stmt->bindParam(':tcno', $tcno);
        $stmt->bindParam(':plaka', $plaka);
        return $stmt->execute();
    }

    // Kiralama listesi
    public function kiralamalistesi()
    {
        $sql = "SELECT k.*, m.adi AS musteri_adi, m.soyadi AS musteri_soyadi, a.model AS arac_modeli 
                FROM kiralama k 
                INNER JOIN musteriler m ON k.tcno = m.tcno 
                INNER JOIN arabalar a ON k.plaka = a.plaka";
        return $this->fetchAllData($sql);
    }

    // Belirli bir kiralama detayı
    public function kiralamadetayi($tcno, $plaka)
    {
        try {
            $sql = "
                SELECT k.*, m.adi AS musteri_adi, m.soyadi AS musteri_soyadi, a.model AS arac_modeli 
                FROM kiralama k
                INNER JOIN musteriler m ON k.tcno = m.tcno
                INNER JOIN arabalar a ON k.plaka = a.plaka
                WHERE k.tcno = :tcno AND k.plaka = :plaka
            ";
            $stmt = $this->db->prepare($sql);
            $stmt->bindParam(':tcno', $tcno);
            $stmt->bindParam(':plaka', $plaka);
            $stmt->execute();
            return $stmt->fetch(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            return null;
        }
    }
}

?>