<?php

/**
 * Database bağlantısı
 * 
 */

define('DB_TYPE', 'mysql');
define('DB_HOST', 'localhost');
define('DB_NAME', 'rentacar');
define('DB_USER', 'ogrenci');
define('DB_PASS', '12345');