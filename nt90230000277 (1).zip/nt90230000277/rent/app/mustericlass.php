<?php

include_once 'config.php';
include_once 'db_cnn.php';

class Musteriler extends DBConnect
{
    public function __construct()
    {
        parent::__construct();
    }
    public function arama($search)
    {
        $sql = "SELECT * FROM musteriler WHERE tcno LIKE ? OR adi LIKE ?";
        try {
            $stmt = $this->db->prepare($sql);
            $stmt->execute(["%$search%", "%$search%"]);
            return $stmt->fetchAll(PDO::FETCH_ASSOC); // Birden fazla sonuç döneceğinden fetchAll() kullanmak uygundur
        } catch (PDOException $e) {
            echo 'Arama hatası: ' . $e->getMessage();
            return false;
        }
    }
    // Müşteri ekleme
    public function musteriekle($tcno, $ehliyetbilgileri, $tlf, $adi, $soyadi, $email)
    {
        $sql = "INSERT INTO musteriler (tcno, ehliyetbilgileri, tlf, adi, soyadi, email) 
                VALUES (?, ?, ?, ?, ?, ?)";
        try {
            $stmt = $this->db->prepare($sql);
            $stmt->execute([$tcno, $ehliyetbilgileri, $tlf, $adi, $soyadi, $email]);
            return true;
        } catch (PDOException $e) {
            echo 'Müşteri ekleme hatası: ' . $e->getMessage();
            return false;
        }
    }

    // Müşteri güncelleme
    public function musteriguncelle($tcno, $ehliyetbilgileri, $tlf, $adi, $soyadi, $email)
    {
        $sql = "UPDATE musteriler SET ehliyetbilgileri = ?, tlf = ?, adi = ?, soyadi = ?, email = ? WHERE tcno = ?";
        try {
            $stmt = $this->db->prepare($sql);
            $stmt->execute([$ehliyetbilgileri, $tlf, $adi, $soyadi, $email, $tcno]);
            return true;
        } catch (PDOException $e) {
            echo 'Müşteri güncelleme hatası: ' . $e->getMessage();
            return false;
        }
    }

    // Müşteri silme
    public function musterisil($tcno)
    {
        $sql = "DELETE FROM musteriler WHERE tcno = ?";
        try {
            $stmt = $this->db->prepare($sql);
            $stmt->execute([$tcno]);
            return true;
        } catch (PDOException $e) {
            echo 'Müşteri silme hatası: ' . $e->getMessage();
            return false;
        }
    }

    // Müşteri listesi
    public function musterilerilistele()
    {
        $sql = "SELECT * FROM musteriler";
        return $this->fetchAllData($sql);
    }

    // Belirli bir müşteri detayı
    public function musteriDetayi($tcno)
    {
        $sql = "SELECT * FROM musteriler WHERE tcno = ?";
        try {
            $stmt = $this->db->prepare($sql);
            $stmt->execute([$tcno]);
            return $stmt->fetch(PDO::FETCH_ASSOC); // Tek bir müşteri kaydı döndürülecekse fetch() kullanmak uygundur
        } catch (PDOException $e) {
            echo 'Müşteri detayı getirme hatası: ' . $e->getMessage();
            return false;
        }
    }
}

?>