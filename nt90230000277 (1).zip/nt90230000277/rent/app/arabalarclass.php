<?php

include_once 'config.php';
include_once 'db_cnn.php';

class Arabalar extends DBConnect
{
    public function __construct()
    {
        parent::__construct();
    }

    // Araç ekleme
    public function aracekle($plaka, $km, $model, $renk, $fiyat, $otomatik, $depozito, $yakitturu, $motorgucu, $yas, $saseno)
    {
        $sql = "INSERT INTO arabalar (plaka, km, model, renk, fiyat, otomatik, depozito, yakitturu, motorgucu, yas, saseno) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try {
            $stmt = $this->db->prepare($sql);
            $stmt->execute([$plaka, $km, $model, $renk, $fiyat, $otomatik, $depozito, $yakitturu, $motorgucu, $yas, $saseno]);
            return true;
        } catch (PDOException $e) {
            echo 'Araç ekleme hatası: ' . $e->getMessage();
            return false;
        }
    }

    // Araç güncelleme
    public function aracguncelle($plaka, $km, $model, $renk, $fiyat, $otomatik, $depozito, $yakitturu, $motorgucu, $yas, $saseno)
    {
        $sql = "UPDATE arabalar SET km = ?, model = ?, renk = ?, fiyat = ?, otomatik = ?, depozito = ?, yakitturu = ?, motorgucu = ?, yas = ?, saseno = ? WHERE plaka = ?";
        try {
            $stmt = $this->db->prepare($sql);
            $stmt->execute([$km, $model, $renk, $fiyat, $otomatik, $depozito, $yakitturu, $motorgucu, $yas, $saseno, $plaka]);
            return true;
        } catch (PDOException $e) {
            echo 'Araç güncelleme hatası: ' . $e->getMessage();
            return false;
        }
    }

    // Araç silme
    public function aracsil($plaka)
    {
        $sql = "DELETE FROM arabalar WHERE plaka = ?";
        try {
            $stmt = $this->db->prepare($sql);
            $stmt->execute([$plaka]);
            return true;
        } catch (PDOException $e) {
            echo 'Araç silme hatası: ' . $e->getMessage();
            return false;
        }
    }

    // Araç listesi
    public function araclarilistele()
    {
        $sql = "SELECT * FROM arabalar";
        return $this->fetchAllData($sql);
    }

    // Belirli bir araç detayı
    public function aracdetayi($plaka)
    {
        $sql = "SELECT * FROM arabalar WHERE plaka = ?";
        try {
            $stmt = $this->db->prepare($sql);
            $stmt->execute([$plaka]);
            return $stmt->fetch(PDO::FETCH_ASSOC); // Tek bir kayıt döndürülecekse fetch() kullanmak uygundur
        } catch (PDOException $e) {
            echo 'Araç detayı getirme hatası: ' . $e->getMessage();
            return false;
        }
    }
}

?>