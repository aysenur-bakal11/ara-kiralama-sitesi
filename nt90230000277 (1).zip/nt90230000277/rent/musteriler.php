<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Müşteriler</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome for icons -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #121212;
            color: #ffffff;
        }

        .navbar-dark .navbar-brand,
        .navbar-dark .nav-link {
            color: rgba(255, 255, 255, 0.85);
        }

        .navbar-dark .nav-link.active {
            font-weight: bold;
        }

        .navbar-light {
            background-color: #212121;
        }

        .container {
            background-color: #1f1f1f;
            border-radius: 8px;
            padding: 30px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
        }

        .form-control,
        .input-group-text {
            background-color: #333;
            border: 1px solid #555;
            color: #fff;
        }

        .form-control:focus,
        .input-group-text:focus {
            background-color: #444;
            border-color: #007bff;
            box-shadow: 0 0 0 0.2rem rgba(38, 143, 255, 0.25);
        }

        .table {
            background-color: #222;
            color: #fff;
        }

        .table thead {
            background-color: #333;
        }

        .table-striped tbody tr:nth-child(odd) {
            background-color: #333;
        }

        .btn-warning {
            background-color: #f0ad4e;
            border-color: #f0ad4e;
        }

        .btn-warning:hover {
            background-color: #ec971f;
            border-color: #ec971f;
        }

        .btn-danger {
            background-color: #e74c3c;
            border-color: #e74c3c;
        }

        .btn-danger:hover {
            background-color: #c0392b;
            border-color: #c0392b;
        }

        .btn-sm {
            padding: 5px 10px;
            font-size: 0.875rem;
        }

        .navbar-toggler-icon {
            background-color: #ffffff;
        }
    </style>
</head>

<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <a class="navbar-brand" href="index.php">Şirket Adı</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
                aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" href="index.php">Anasayfa</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="musteriler.php">Müşteri Listesi</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="musteriekle.php">Müşteri Ekle</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Müşteri Listesi -->
    <div class="container mt-4">
        <div class="row justify-content-between">
            <h2 class="mb-4 col-lg-4 text-warning">Müşteri Listesi</h2>
            <div class="input-group w-50 mb-4">
                <input type="text" class="form-control" placeholder="Arama yap..." name="search">
                <button class="btn btn-primary" type="submit">
                    <i class="fas fa-search"></i>
                </button>
            </div>
        </div>
        <table class="table table-striped">
            <thead>
                <tr>
                    <th scope="col">TC No</th>
                    <th scope="col">Ehliyet Bilgileri</th>
                    <th scope="col">Telefon</th>
                    <th scope="col">Adı</th>
                    <th scope="col">Soyadı</th>
                    <th scope="col">Email</th>
                    <th scope="col">Güncelle</th>
                    <th scope="col">Sil</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($customers): ?>
                    <?php foreach ($customers as $customer): ?>
                        <tr>
                            <td><?= $customer['tcno'] ?></td>
                            <td><?= $customer['ehliyetbilgileri'] ?></td>
                            <td><?= $customer['tlf'] ?></td>
                            <td><?= $customer['adi'] ?></td>
                            <td><?= $customer['soyadi'] ?></td>
                            <td><?= $customer['email'] ?></td>
                            <td>
                                <a href="musteriguncelle.php?tcno=<?= $customer['tcno'] ?>" class="btn btn-warning btn-sm">
                                    <i class="fas fa-edit"></i> Güncelle
                                </a>
                            </td>
                            <td>
                                <a href="musterisil.php?tcno=<?= $customer['tcno'] ?>" class="btn btn-danger btn-sm">
                                    <i class="fas fa-trash"></i> Sil
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="8" class="text-center text-danger">Kaydılı müşteri bulunamadı.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>
