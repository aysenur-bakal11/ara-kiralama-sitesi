<?php 
include_once 'app/config.php';
include_once 'app/arabalarclass.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $plaka = $_POST['plaka'];
    $km = $_POST['km'];
    $model = $_POST['model'];
    $renk = $_POST['renk'];
    $fiyat = $_POST['fiyat'];
    $otomatik = isset($_POST['otomatik']) ? 1 : 0;
    $depozito = $_POST['depozito'];
    $yakit_turu = $_POST['yakit_turu'];
    $motor_gucu = $_POST['motor_gucu'];
    $yas = $_POST['yas'];
    $sase_no = $_POST['sase_no'];

    $araba = new Arabalar();
    if ($araba->aracekle($plaka, $km, $model, $renk, $fiyat, $otomatik, $depozito, $yakit_turu, $motor_gucu, $yas, $sase_no)) {
        echo "Araç başarıyla eklendi.";
    } else {
        die("Araç eklenirken bir hata oluştu.");
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Araç Ekle</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #121212; /* Koyu arka plan */
            color: #ffffff; /* Açık metin rengi */
        }

        .navbar-dark .navbar-brand,
        .navbar-dark .nav-link {
            color: rgba(255, 255, 255, 0.85);
        }

        .navbar-dark .nav-link.active {
            font-weight: bold;
        }

        .form-control,
        .form-check-input {
            background-color: #1f1f1f; /* Form alanları için koyu arka plan */
            color: #ffffff; /* Form yazı rengi */
            border: 1px solid #444; /* İnce kenarlık */
        }

        .form-control:focus,
        .form-check-input:focus {
            background-color: #333; /* Form alanları odak rengi */
            border-color: #555; /* Kenarlık odak rengi */
        }

        .btn-primary {
            background-color: #0d6efd; /* Buton rengi */
            border-color: #0a58ca;
        }

        .btn-primary:hover {
            background-color: #0b5ed7;
        }
    </style>
</head>

<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <a class="navbar-brand" href="index.php">Şirket Adı</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
                aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" href="index.php">Anasayfa</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" aria-current="page" href="araclar.php">Araç Listesi</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="aracekle.php">Araç Ekle</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <div class="container mt-5">
        <h2 class="text-light">Araç Ekle</h2>
        <form method="POST" action="">
            <div class="mb-3">
                <label for="plaka" class="form-label">Plaka</label>
                <input type="text" class="form-control" id="plaka" name="plaka" required>
            </div>
            <div class="mb-3">
                <label for="km" class="form-label">KM</label>
                <input type="number" class="form-control" id="km" name="km" required>
            </div>
            <div class="mb-3">
                <label for="model" class="form-label">Model</label>
                <input type="text" class="form-control" id="model" name="model" required>
            </div>
            <div class="mb-3">
                <label for="renk" class="form-label">Renk</label>
                <input type="text" class="form-control" id="renk" name="renk" required>
            </div>
            <div class="mb-3">
                <label for="fiyat" class="form-label">Fiyat</label>
                <input type="number" class="form-control" id="fiyat" name="fiyat" required>
            </div>
            <div class="form-check mb-3">
                <input type="checkbox" class="form-check-input" id="otomatik" name="otomatik">
                <label for="otomatik" class="form-check-label">Otomatik</label>
            </div>
            <div class="mb-3">
                <label for="depozito" class="form-label">Depozito</label>
                <input type="number" class="form-control" id="depozito" name="depozito" required>
            </div>
            <div class="mb-3">
                <label for="yakit_turu" class="form-label">Yakıt Türü</label>
                <input type="text" class="form-control" id="yakit_turu" name="yakit_turu" required>
            </div>
            <div class="mb-3">
                <label for="motor_gucu" class="form-label">Motor Gücü</label>
                <input type="number" class="form-control" id="motor_gucu" name="motor_gucu" required>
            </div>
            <div class="mb-3">
                <label for="yas" class="form-label">Yaş</label>
                <input type="number" class="form-control" id="yas" name="yas" required>
            </div>
            <div class="mb-3">
                <label for="sase_no" class="form-label">Şase No</label>
                <input type="text" class="form-control" id="sase_no" name="sase_no" required>
            </div>
            <button type="submit" class="btn btn-primary">Ekle</button>
        </form>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>
