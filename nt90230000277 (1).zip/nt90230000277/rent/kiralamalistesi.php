<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kiralama Listesi</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #121212;
            color: #ffffff;
        }

        .navbar-dark .navbar-brand,
        .navbar-dark .nav-link {
            color: rgba(255, 255, 255, 0.85);
        }

        .navbar-dark .nav-link.active {
            font-weight: bold;
        }

        .table {
            color: #ffffff;
        }

        .table-striped > tbody > tr:nth-of-type(odd) {
            --bs-table-accent-bg: #1f1f1f;
        }

        .table-striped > tbody > tr:nth-of-type(even) {
            --bs-table-accent-bg: #2a2a2a;
        }

        .table-striped > tbody > tr:hover {
            --bs-table-accent-bg: #3a3a3a;
        }

        .form-control {
            background-color: #1f1f1f;
            color: #ffffff;
            border: 1px solid #333;
        }

        .form-control:focus {
            border-color: #555;
            box-shadow: none;
        }

        .btn-primary {
            background-color: #007bff;
            border-color: #007bff;
        }

        .btn-warning {
            background-color: #ffc107;
            border-color: #ffc107;
            color: #000;
        }

        .btn-danger {
            background-color: #dc3545;
            border-color: #dc3545;
        }
    </style>
</head>

<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <a class="navbar-brand" href="index.html">Şirket Adı</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
                aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" href="index.php">Anasayfa</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="kiralamalistesi.php">Kiralama Listesi</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="kiralamaekle.php">Kiralama Ekle</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Kiralama Listesi -->
    <div class="container mt-4">
        <div class="row justify-content-between">
            <h2 class="mb-4 col-lg-4">Kiralama Listesi</h2>
            <div class="input-group w-50 mb-4">
                <input type="text" class="form-control" placeholder="Arama yap..." name="search">
                <button class="btn btn-primary" type="submit">
                    <i class="fas fa-search"></i>
                </button>
            </div>
        </div>
        <table class="table table-striped">
            <thead>
                <tr>
                    <th scope="col">TC No</th>
                    <th scope="col">Plaka</th>
                    <th scope="col">Şase No</th>
                    <th scope="col">Başlangıç Tarihi</th>
                    <th scope="col">Bitiş Tarihi</th>
                    <th scope="col">Ücret</th>
                    <th scope="col">Güncelle</th>
                    <th scope="col">Sil</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($rentals as $rental): ?>
                    <tr>
                        <td><?= $rental['tcno'] ?></td>
                        <td><?= $rental['plaka'] ?></td>
                        <td><?= $rental['saseno'] ?></td>
                        <td><?= $rental['baslangic'] ?></td>
                        <td><?= $rental['bitis'] ?></td>
                        <td><?= $rental['ucret'] ?> TL</td>
                        <td>
                            <a href="kiralamaguncelle.php?tcno=<?= $rental['tcno'] ?>&plaka=<?= $rental['plaka'] ?>"
                                class="btn btn-warning btn-sm">
                                <i class="fas fa-edit"></i> Güncelle
                            </a>
                        </td>
                        <td>
                            <a href="kiralamasil.php?tcno=<?= $rental['tcno'] ?>&plaka=<?= $rental['plaka'] ?>"
                                class="btn btn-danger btn-sm">
                                <i class="fas fa-trash"></i> Sil
                            </a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <!-- Font Awesome -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/js/all.min.js"></script>
</body>

</html>
