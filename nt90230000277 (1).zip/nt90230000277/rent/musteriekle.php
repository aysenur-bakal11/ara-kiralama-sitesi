<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Müşteri Ekle</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome (Opsiyonel, ikonlar için) -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #121212;
            color: #ffffff;
        }

        .navbar-dark .navbar-brand,
        .navbar-dark .nav-link {
            color: rgba(255, 255, 255, 0.85);
        }

        .navbar-dark .nav-link.active {
            font-weight: bold;
        }

        .navbar-light {
            background-color: #212121;
        }

        .container {
            background-color: #1f1f1f;
            border-radius: 8px;
            padding: 30px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
        }

        .form-label {
            color: #ccc;
        }

        .form-control {
            background-color: #333;
            border: 1px solid #555;
            color: #fff;
        }

        .form-control:focus {
            background-color: #444;
            border-color: #007bff;
            box-shadow: 0 0 0 0.2rem rgba(38, 143, 255, 0.25);
        }

        .btn-primary {
            background-color: #007bff;
            border-color: #007bff;
        }

        .btn-primary:hover {
            background-color: #0056b3;
            border-color: #0056b3;
        }

        .btn {
            border-radius: 5px;
        }

        .navbar-toggler-icon {
            background-color: #ffffff;
        }

        .text-success {
            color: #28a745 !important;
        }

        .text-danger {
            color: #e74c3c !important;
        }
    </style>
</head>

<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <a class="navbar-brand" href="index.php">Şirket Adı</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
                aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" href="index.php">Anasayfa</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="musteriler.php">Müşteri Listesi</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="musteriekle.php">Müşteri Ekle</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Müşteri Ekleme Formu -->
    <div class="container mt-4">
        <h2 class="mb-4 text-success">Müşteri Ekle</h2>
        <form action="" method="POST">
            <div class="mb-3">
                <label for="adi" class="form-label">Adı</label>
                <input type="text" class="form-control" id="adi" name="adi" required>
            </div>
            <div class="mb-3">
                <label for="soyadi" class="form-label">Soyadı</label>
                <input type="text" class="form-control" id="soyadi" name="soyadi" required>
            </div>
            <div class="mb-3">
                <label for="tcno" class="form-label">TC Kimlik Numarası</label>
                <input type="text" class="form-control" id="tcno" name="tcno" required>
            </div>
            <div class="mb-3">
                <label for="tlf" class="form-label">Telefon</label>
                <input type="text" class="form-control" id="tlf" name="tlf" required>
            </div>
            <div class="mb-3">
                <label for="email" class="form-label">Email</label>
                <input type="email" class="form-control" id="email" name="email" required>
            </div>
            <div class="mb-3">
                <label for="ehliyet" class="form-label">Ehliyet Bilgisi</label>
                <textarea class="form-control" id="ehliyet" name="ehliyet" rows="3" required></textarea>
            </div>
            <button type="submit" class="btn btn-primary">Kaydet</button>
        </form>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>
