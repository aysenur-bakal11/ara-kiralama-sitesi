<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ana Sayfa</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #121212;
            color: #ffffff;
        }
        .navbar {
            background-color: #000000;
        }
        .navbar-brand, .nav-link {
            color: #ffffff !important;
        }
        .nav-link.active {
            font-weight: bold;
        }
        .nav-link:hover {
            color: #bbbbbb !important;
        }
    </style>
</head>

<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark">
        <div class="container">
            <a class="navbar-brand" href="#">Şirket Adı</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
                aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="index.php">Anasayfa</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="musteriler.php">Müşteriler</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="araclar.php">Araçlar</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="kiralamalistesi.php">Kiralama Listesi</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Ana Sayfa İçeriği -->
    <div class="container mt-4">
        <h1 class="text-center">Hoş Geldiniz</h1>
        <p class="text-center">Bu sistem araç kiralama işlemlerini kolaylaştırmak için tasarlanmıştır.</p>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>
