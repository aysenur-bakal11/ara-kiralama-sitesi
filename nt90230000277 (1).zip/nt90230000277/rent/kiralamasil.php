<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kiralama Sil</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #121212;
            color: #ffffff;
        }

        .navbar-dark .navbar-brand,
        .navbar-dark .nav-link {
            color: rgba(255, 255, 255, 0.85);
        }

        .navbar-dark .nav-link.active {
            font-weight: bold;
        }

        .btn-secondary {
            background-color: #6c757d;
            border-color: #6c757d;
        }

        .btn-danger {
            background-color: #dc3545;
            border-color: #dc3545;
        }

        .container {
            background-color: #1f1f1f;
            border-radius: 8px;
            padding: 30px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
        }

        .border {
            border-color: #333;
        }

        .border p {
            color: #ccc;
        }

        .text-danger {
            color: #e74c3c !important;
        }

        .navbar-light {
            background-color: #212121;
        }

        .navbar-toggler-icon {
            background-color: #ffffff;
        }

        .btn {
            border-radius: 5px;
        }
    </style>
</head>

<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <a class="navbar-brand" href="index.html">Şirket Adı</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
                aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" href="index.php">Anasayfa</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="kiralamalistesi.php">Kiralama Listesi</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="kiralamaekle.php">Kiralama Ekle</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Kiralama Silme -->
    <div class="container mt-4">
        <h2 class="mb-4 text-danger">Kiralama Sil</h2>
        <p class="mb-4">Aşağıdaki kiralama kaydını silmek istediğinize emin misiniz?</p>

        <!-- Kiralama Bilgileri -->
        <div class="border p-3 mb-4">
            <p><strong>Başlangıç Tarihi:</strong> <?= $rental['baslangic'] ?></p>
            <p><strong>Bitiş Tarihi:</strong> <?= $rental['bitis'] ?></p>
            <p><strong>Ücret:</strong> <?= $rental['ucret'] ?> TL</p>
        </div>

        <!-- Silme İşlemi -->
        <form action="" method="POST">
            <div class="d-flex justify-content-between">
                <a href="kiralamalistesi.php" class="btn btn-secondary">İptal</a>
                <button type="submit" class="btn btn-danger">Kiralama Sil</button>
            </div>
        </form>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>
