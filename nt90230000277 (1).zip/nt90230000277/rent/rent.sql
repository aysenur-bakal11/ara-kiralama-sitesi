-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Anamakine: 127.0.0.1
-- Üretim Zamanı: 20 Kas 2024, 10:24:15
-- Sunucu sürümü: 10.4.32-MariaDB
-- PHP Sürümü: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Veritabanı: `rent`
--

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `arabalar`
--

CREATE TABLE `arabalar` (
  `plaka` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '''''',
  `km` mediumint(8) UNSIGNED DEFAULT NULL,
  `model` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `renk` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fiyat` int(10) UNSIGNED DEFAULT NULL,
  `otomatik` enum('E','H') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'E',
  `depozito` int(10) UNSIGNED DEFAULT NULL,
  `yakitturu` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `motorgucu` smallint(5) UNSIGNED DEFAULT NULL,
  `yas` tinyint(3) UNSIGNED DEFAULT NULL,
  `saseno` bigint(20) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Tablo döküm verisi `arabalar`
--

INSERT INTO `arabalar` (`plaka`, `km`, `model`, `renk`, `fiyat`, `otomatik`, `depozito`, `yakitturu`, `motorgucu`, `yas`, `saseno`) VALUES
('1232133', 23, 'toyota', 'beyaz', 32, 'E', 2323, 'dsafaw', 32, 23, 2324);

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `kiralama`
--

CREATE TABLE `kiralama` (
  `tcno` bigint(20) UNSIGNED DEFAULT NULL,
  `plaka` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `saseno` bigint(20) UNSIGNED DEFAULT NULL,
  `baslangic` datetime DEFAULT NULL,
  `bitis` datetime DEFAULT NULL,
  `ucret` int(10) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Tablo döküm verisi `kiralama`
--

INSERT INTO `kiralama` (`tcno`, `plaka`, `saseno`, `baslangic`, `bitis`, `ucret`) VALUES
(12625697862, '123213', NULL, '2024-11-20 00:00:00', '2024-11-22 00:00:00', 32),
(12625697862, '1232133', NULL, '2024-11-21 00:00:00', '2024-11-23 00:00:00', 32);

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `musteriler`
--

CREATE TABLE `musteriler` (
  `tcno` bigint(20) UNSIGNED DEFAULT NULL,
  `ehliyetbilgileri` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `tlf` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `adi` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `soyadi` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Tablo döküm verisi `musteriler`
--

INSERT INTO `musteriler` (`tcno`, `ehliyetbilgileri`, `tlf`, `adi`, `soyadi`, `email`) VALUES
(12625697862, 'yess', '05382268680', 'Muhammett', 'Karagöz', 'kozmozzxd@gmail.com');

--
-- Dökümü yapılmış tablolar için indeksler
--

--
-- Tablo için indeksler `arabalar`
--
ALTER TABLE `arabalar`
  ADD UNIQUE KEY `Index 1` (`plaka`),
  ADD UNIQUE KEY `Index 2` (`saseno`),
  ADD KEY `Index 3` (`model`) USING BTREE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
